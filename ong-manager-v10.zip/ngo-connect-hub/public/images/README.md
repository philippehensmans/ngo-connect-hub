# Dossier Images

Ce dossier contient les images de l'application.

## Logo personnalisé

Pour afficher votre logo dans le header de l'application :

1. Placez votre fichier logo dans ce dossier avec le nom **`logo.png`**
2. Le logo sera automatiquement affiché dans la barre du haut
3. Hauteur recommandée : 80-120px (sera redimensionné à 40px de hauteur)
4. Format : PNG avec transparence recommandé

Si le fichier `logo.png` n'existe pas, l'application affichera un carré bleu avec l'initiale du nom de l'équipe.

## Autres images

Vous pouvez placer d'autres images dans ce dossier selon vos besoins.
